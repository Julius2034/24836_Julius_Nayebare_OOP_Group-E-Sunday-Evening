package unchackedExceptions;

public class  NumberFormatExceptionExample {
    public static void main(String[] args) {
        try {
            int number = Integer.parseInt("not_a_number");
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException occurred: " + e.getMessage());
        }
    }
}

