package unchackedExceptions;

public class IllegalArgumentExceptionExample {
    public static void main(String[] args) {
        try {
            Thread.sleep(-1000);
        } catch (IllegalArgumentException e) {
            System.out.println("IllegalArgumentException occurred: " + e.getMessage());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

