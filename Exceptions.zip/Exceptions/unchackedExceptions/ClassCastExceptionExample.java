package unchackedExceptions;

public class ClassCastExceptionExample {
    public static void main(String[] args) {
        try {

            Object obj = Integer.valueOf(42);

            // Attempt to cast the Integer object to a String (invalid cast)
            String str = (String) obj;

            System.out.println("This will not print: " + str);
        } catch (ClassCastException e) {
            // Handle ClassCastException
            System.out.println("ClassCastException occurred: " + e.getMessage());
        }
    }
}

