package CheckedExpections;
import java.io.*;
public class FileNotfoundExcetionExample {
    public static void main(String[] args) {
        try {
            FileInputStream file = new FileInputStream("missing_file.txt");
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFoundException occurred: " + e.getMessage());
        }
    }
}

