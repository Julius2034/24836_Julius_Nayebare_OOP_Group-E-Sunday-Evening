package CheckedExpections;
import java.sql.*;
public class SQLExceptionExample {
    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection("Muntu:mysql://localhost:3306/non_existent_db", "AMON", "well1233");
        } catch (SQLException e) {
            System.out.println("SQLException occurred: " + e.getMessage());
        }
    }
}
