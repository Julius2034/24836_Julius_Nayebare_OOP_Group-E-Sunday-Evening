package CheckedExpections;
import java.io.*;
public class EOFExceptionExample {
    public static void main(String[] args) {
        File file = new File("data.dat");

        if (!file.exists()) {
            System.out.println("File 'data.dat' does not exist. Please create the file and add serialized objects.");
            return;
        }

        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(file))) {
            System.out.println("Reading objects from the file...");
            while (true) {
                System.out.println(input.readObject());
            }
        } catch (EOFException e) {
            System.out.println("EOFException occurred: End of file reached.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("An error occurred while processing the file:");
            e.printStackTrace();
        }
    }
}


